package com.example.admin.du_an_1.UI;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.admin.du_an_1.Adapter.CategoryAdap;
import com.example.admin.du_an_1.Controller.CategoryService;
import com.example.admin.du_an_1.DAO.daoCategory;
import com.example.admin.du_an_1.R;
import com.example.admin.du_an_1.Repository.Category;

import java.util.ArrayList;
import java.util.List;

public class CategoryActivity extends AppCompatActivity {

    FloatingActionButton btnAdd_Category;
    ListView lv_Category;

    private ArrayAdapter<Category> adapter;
    private daoCategory dao_Category;

    private List<Category> lsCat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);

        lv_Category = findViewById( R.id.lv_Category );
        btnAdd_Category = findViewById( R.id.btnAdd_Category );

        btnAdd_Category.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Dialog_Add();
            }
        } );

    }

//    public void checkedCat(String name){
//        if(this.Service_cat.addCategory( name )){
//            Toast.makeText( this,"Congratulation",Toast.LENGTH_SHORT ).show();
//        }else {
//            Toast.makeText( this,"Try again !",Toast.LENGTH_SHORT ).show();
//        }
//    }

    @Override
    protected void onResume() {
        super.onResume();


        dao_Category = daoCategory.getInstance( getBaseContext() );
        lsCat = dao_Category.getAllItem();

        adapter = new CategoryAdap( this,R.layout.item_cat,(ArrayList<Category>)lsCat );
        lv_Category.setAdapter( adapter );
//        mList_type.clear();
        adapter.notifyDataSetChanged();

        lv_Category.setOnItemClickListener( new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

            }
        } );

    }

    //
    //
     //////////////////////////////////////
    // Sử dụng Dialog để thêm Thể Loại. //
    //
    //
    public void Dialog_Add(){

        LayoutInflater inflater = getLayoutInflater();
        View view = inflater.inflate( R.layout.dialog_add_category,null );

        final EditText edtDialog_addCategory = (EditText)view.findViewById( R.id.edtDialog_addCategory );

        AlertDialog.Builder mBuilder = new AlertDialog.Builder( this );
        mBuilder.setView( view ).setTitle("ADD CATEGORY").setPositiveButton( "Done", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

//                for (i=0;i<lsCat.size();i++){
//                    if (edtDialog_addCategory.getText().toString().equals( lsCat.get( i ).getName() )){
//                        Toast.makeText( getBaseContext(),"This is Match",Toast.LENGTH_SHORT ).show();
//                    }
//
//                }
//
//                if (edtDialog_addCategory.getText().toString().isEmpty()){
//                    Toast.makeText( getBaseContext(),"Add Category fail",Toast.LENGTH_SHORT ).show();
//                }else {
//                    mCategory = new Category();
//                    mCategory.setName( edtDialog_addCategory.getText().toString() );
//
//                    dao_Category.insertCat( mCategory );
//                }
                CategoryService ServiceCat = new CategoryService( getBaseContext() );
                ServiceCat.addCategory( edtDialog_addCategory.getText().toString() );
                finish();
                startActivityForResult( new Intent( getBaseContext(),CategoryActivity.class ),0 );
            }
        } ).setNegativeButton( "Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
                dialogInterface.cancel();
            }
        } ).create().show();

    }
}
