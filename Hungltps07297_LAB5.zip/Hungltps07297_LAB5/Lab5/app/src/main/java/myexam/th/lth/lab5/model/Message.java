package myexam.th.lth.lab5.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Message {
    @SerializedName("success")
    @Expose
    private String success;

    @SerializedName("message")
    @Expose
    private String message;


    public String getSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }
}
