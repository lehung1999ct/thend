package myexam.th.lth.lab5;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import myexam.th.lth.lab5.model.ProductList;
import myexam.th.lth.lab5.retrofit.BackendClient;
import myexam.th.lth.lab5.retrofit.ServiceGenerator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private ProductList productList = null;
    private RecyclerView rvProductList;
    private ProductListAdapter adapter;
    private Button btnCreate;
    public static boolean isUpdated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rvProductList = findViewById(R.id.rvContactList);
        btnCreate = findViewById(R.id.btnCreate);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, CreateActivity.class);
                startActivity(intent);
            }
        });
        getDataFromServer();
    }

    private void getDataFromServer() {
        if (productList != null && productList.getProducts() != null) {
            productList.getProducts().clear();
        }
        BackendClient backendClient = ServiceGenerator.createService(BackendClient.class);
        backendClient.getProductList()
                .enqueue(new Callback<ProductList>() {

                    @Override
                    public void onResponse(Call<ProductList> call, Response<ProductList> response) {
                        Log.d("contactList", call.request().url().toString());
                        if (response != null) {
                            productList = response.body();
                            Log.d("contactList", productList.toString());
                            rvProductList.setLayoutManager(new LinearLayoutManager(MainActivity.this));
                            adapter = new ProductListAdapter(MainActivity.this);
                            rvProductList.setAdapter(adapter);
                            adapter.addAll(productList.getProducts());
                        }
                    }

                    @Override
                    public void onFailure(Call<ProductList> call, Throwable t) {
                        Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (isUpdated) {
            isUpdated = false;
            getDataFromServer();
        }
    }
}
