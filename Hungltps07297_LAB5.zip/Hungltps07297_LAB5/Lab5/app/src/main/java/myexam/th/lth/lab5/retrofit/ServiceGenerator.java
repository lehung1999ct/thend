package myexam.th.lth.lab5.retrofit;

import com.google.gson.Gson;

import myexam.th.lth.lab5.Constants;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ServiceGenerator {

    private static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl( Constants.WEB_API)
            .addConverterFactory(GsonConverterFactory.create(new Gson()))
            .build();

    public static <S> S createService(Class<S> serviceClass) {
        return retrofit.create(serviceClass);
    }
}
