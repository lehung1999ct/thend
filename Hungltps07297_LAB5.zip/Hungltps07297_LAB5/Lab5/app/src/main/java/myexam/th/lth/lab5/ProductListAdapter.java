package myexam.th.lth.lab5;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.util.SortedList;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

import myexam.th.lth.lab5.model.Message;
import myexam.th.lth.lab5.model.Product;
import myexam.th.lth.lab5.retrofit.BackendClient;
import myexam.th.lth.lab5.retrofit.ServiceGenerator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProductListAdapter extends RecyclerView.Adapter<ProductListAdapter.ViewHolder> {

    private static final String TAG = "ProductList";

    private SortedList<Product> productList;
    private LayoutInflater layoutInflater;
    private Activity activity;

    public ProductListAdapter(Activity activity) {
        this.productList = new SortedList<Product>(Product.class, new SortedList.Callback<Product>() {
            @Override
            public void onInserted(int position, int count) {
                Log.d(TAG, "onInserted");
                notifyItemRangeInserted(position, count);
            }

            @Override
            public void onRemoved(int position, int count) {
                Log.d(TAG, "onRemoved");
                notifyItemRangeInserted(position, count);
            }

            @Override
            public void onMoved(int fromPosition, int toPosition) {
                Log.d(TAG, "onMoved");
                notifyItemMoved(fromPosition, toPosition);
            }

            @Override
            public int compare(Product o1, Product o2) {
                Log.d(TAG, "compare");
                return o1.getPid().compareTo(o2.getPid());
            }

            @Override
            public void onChanged(int position, int count) {
                Log.d(TAG, "onChanged");
                notifyItemRangeChanged(position, count);
            }

            @Override
            public boolean areContentsTheSame(Product oldItem, Product newItem) {
                Log.d(TAG, "areContentsTheSame");
                return oldItem.getPid().equals(newItem.getPid());
            }

            @Override
            public boolean areItemsTheSame(Product item1, Product item2) {
                Log.d(TAG, "areItemsTheSame");
                return item1.getPid().equals(item2.getPid());
            }
        });
        this.activity = activity;
        layoutInflater = LayoutInflater.from(activity);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        Log.d("contactList", "onCreateViewHolder");
        View itemView = layoutInflater.inflate(R.layout.item_product, parent, false);
        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {
        Log.d(TAG, "onBindViewHolder");
        final Product product = productList.get(position);
        holder.txtId.setText("ID: " + product.getPid());
        holder.txtName.setText("Name: " + product.getName());
        holder.txtPrice.setText("Price: " + product.getPrice());
        holder.txtCreatedAt.setText("Created At: " + product.getCreated_at());
        holder.txtUpdatedAt.setText("Updated At: " + product.getUpdated_at());

        holder.llItemProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(activity, UpdateActivity.class);
                intent.putExtra("pid", product.getPid());
                activity.startActivity(intent);
            }
        });

        holder.llItemProduct.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(activity);
                builder.setTitle("Delete Product With ID = " + product.getPid());
                builder.setMessage("Are you sure you want to delete?");
                builder.setCancelable(false);
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        deleteData(position, product.getPid());
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
                return false;
            }
        });
    }

    private void deleteData(final int position, final String pid) {
        BackendClient backendClient = ServiceGenerator.createService(BackendClient.class);
        backendClient.deleteProduct(pid).enqueue(new Callback<Message>() {
            @Override
            public void onResponse(Call<Message> call, Response<Message> response) {
                Message message = response.body();
                if(message.getSuccess().equals("1")){
                    Toast.makeText(activity, "Deleted Product With ID = " + pid, Toast.LENGTH_SHORT).show();
                    remove(position);
                }
            }

            @Override
            public void onFailure(Call<Message> call, Throwable t) {
                Toast.makeText(activity, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    public void addAll(List<Product> contactList) {
        Log.d(TAG, "addAll");
        this.productList.beginBatchedUpdates();
        for (int i = 0; i < contactList.size(); i++) {
            this.productList.add(contactList.get(i));
        }
        this.productList.endBatchedUpdates();
    }

    private void remove(int position){
        productList.removeItemAt(position);
        notifyDataSetChanged();
    }

    public void clear() {
        productList.beginBatchedUpdates();
        //remove items at end, to avoid unnecessary array shifting
        while (productList.size() > 0) {
            productList.removeItemAt(productList.size() - 1);
        }
        productList.endBatchedUpdates();
    }

    public Product getItem(int i) {
        return productList.get(i);
    }

    @Override
    public int getItemCount() {
        return productList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        LinearLayout llItemProduct;
        TextView txtId;
        TextView txtName;
        TextView txtPrice;
        TextView txtCreatedAt;
        TextView txtUpdatedAt;

        public ViewHolder(View itemView) {
            super(itemView);
            llItemProduct = itemView.findViewById(R.id.llItemProduct);
            txtId = itemView.findViewById(R.id.txtId);
            txtName = itemView.findViewById(R.id.txtName);
            txtPrice = itemView.findViewById(R.id.txtPrice);
            txtCreatedAt = itemView.findViewById(R.id.txtCreatedAt);
            txtUpdatedAt = itemView.findViewById(R.id.txtUpdatedAt);
        }
    }
}
