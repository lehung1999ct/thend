package myexam.th.lth.lab5;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import myexam.th.lth.lab5.model.Message;
import myexam.th.lth.lab5.retrofit.BackendClient;
import myexam.th.lth.lab5.retrofit.ServiceGenerator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CreateActivity extends AppCompatActivity {

    private EditText edtName;
    private EditText edtPrice;
    private EditText edtDescription;
    private Button btnCreate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create);
        prepareView();
    }

    private void postDataToServer() {
        final String name = edtName.getText().toString();
        final String price = edtPrice.getText().toString();
        final String description = edtDescription.getText().toString();
        BackendClient backendClient = ServiceGenerator.createService(BackendClient.class);
        backendClient.createProduct(name, price, description).enqueue(new Callback<Message>() {
            @Override
            public void onResponse(Call<Message> call, Response<Message> response) {
                Message message = response.body();
                Toast.makeText(CreateActivity.this, message.getMessage(), Toast.LENGTH_LONG).show();
                MainActivity.isUpdated = true;
                CreateActivity.this.finish();
            }

            @Override
            public void onFailure(Call<Message> call, Throwable t) {
                Toast.makeText(CreateActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void prepareView(){
        edtName = findViewById(R.id.edtName);
        edtPrice = findViewById(R.id.edtPrice);
        edtDescription = findViewById(R.id.edtDescription);
        btnCreate = findViewById(R.id.btnCreate);
        btnCreate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postDataToServer();
            }
        });
    }

}
