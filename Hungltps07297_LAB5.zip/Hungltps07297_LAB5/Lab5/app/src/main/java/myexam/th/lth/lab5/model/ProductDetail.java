package myexam.th.lth.lab5.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ProductDetail {
    @SerializedName("product")
    @Expose
    private List<Product> products;

    @SerializedName("success")
    @Expose
    private String success;

    public List<Product> getProducts() {
        return products;
    }

    public String getSuccess() {
        return success;
    }
}
