package myexam.th.lth.lab5;

public class Constants {
    public static final String WEB_API = "http://192.168.1.6/Lab5_ps07297_Android/";
}
