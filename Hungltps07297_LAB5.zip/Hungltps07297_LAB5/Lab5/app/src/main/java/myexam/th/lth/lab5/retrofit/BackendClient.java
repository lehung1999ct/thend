package myexam.th.lth.lab5.retrofit;

import myexam.th.lth.lab5.model.Message;
import myexam.th.lth.lab5.model.ProductDetail;
import myexam.th.lth.lab5.model.ProductList;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
import retrofit2.http.Query;

public interface BackendClient {

    @GET("get_all_product.php")
    Call<ProductList> getProductList();

    @GET("get_product_detail.php")
    Call<ProductDetail> getProductById(@Query("pid") String pid);

    @POST("create_product.php")
    @FormUrlEncoded
    Call<Message> createProduct(@Field("name") String name,
                                @Field("price") String price,
                                @Field("description") String description);

    @POST("update_product.php")
    @FormUrlEncoded
    Call<Message> updateProduct(@Field("pid") String pid,
                                @Field("name") String name,
                                @Field("price") String price,
                                @Field("description") String description);

    @POST("delete_product.php")
    @FormUrlEncoded
    Call<Message> deleteProduct(@Field("pid") String pid);
}
