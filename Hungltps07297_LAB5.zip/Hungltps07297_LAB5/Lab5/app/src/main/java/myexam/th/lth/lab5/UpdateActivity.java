package myexam.th.lth.lab5;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import myexam.th.lth.lab5.model.Message;
import myexam.th.lth.lab5.model.Product;
import myexam.th.lth.lab5.model.ProductDetail;
import myexam.th.lth.lab5.retrofit.BackendClient;
import myexam.th.lth.lab5.retrofit.ServiceGenerator;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateActivity extends AppCompatActivity {

    private String pid = null;
    private EditText edtUpdateName;
    private EditText edtUpdatePrice;
    private EditText edtUpdateDescription;
    private Button btnUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        prepareView();
        pid = getIntent().getExtras().getString("pid");
        Toast.makeText(UpdateActivity.this, "pid = " + pid, Toast.LENGTH_LONG).show();
        prepareData();
    }

    private void prepareData() {
        BackendClient backendClient = ServiceGenerator.createService(BackendClient.class);
        backendClient.getProductById(pid).enqueue(new Callback<ProductDetail>() {
            @Override
            public void onResponse(Call<ProductDetail> call, Response<ProductDetail> response) {
                ProductDetail productDetail = response.body();
                if (productDetail != null && productDetail.getProducts() != null && !productDetail.getProducts().isEmpty()) {
                    Product product = productDetail.getProducts().get(0);
                    if (product != null) {
                        edtUpdateName.setText(product.getName());
                        edtUpdatePrice.setText(product.getPrice());
                        edtUpdateDescription.setText(product.getDescription());
                    }
                }
            }

            @Override
            public void onFailure(Call<ProductDetail> call, Throwable t) {
                Toast.makeText(UpdateActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void postDataToServer() {
        final String name = edtUpdateName.getText().toString();
        final String price = edtUpdatePrice.getText().toString();
        final String description = edtUpdateDescription.getText().toString();
        BackendClient backendClient = ServiceGenerator.createService(BackendClient.class);
        backendClient.updateProduct(pid, name, price, description).enqueue(new Callback<Message>() {
            @Override
            public void onResponse(Call<Message> call, Response<Message> response) {
                Message message = response.body();
                Toast.makeText(UpdateActivity.this, message.getMessage(), Toast.LENGTH_LONG).show();
                MainActivity.isUpdated = true;
                UpdateActivity.this.finish();
            }

            @Override
            public void onFailure(Call<Message> call, Throwable t) {
                Toast.makeText(UpdateActivity.this, t.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }

    private void prepareView() {
        edtUpdateName = findViewById(R.id.edtUpdateName);
        edtUpdatePrice = findViewById(R.id.edtUpdatePrice);
        edtUpdateDescription = findViewById(R.id.edtUpdateDescription);
        btnUpdate = findViewById(R.id.btnUpdate);
        btnUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postDataToServer();
            }
        });
    }

}
